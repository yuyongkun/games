# HardestGame
游戏 - 见缝插针
<br />
这是一个简单的HTML5小游戏 - 见缝插针的源码, 用canvas实现, 仅供大家交流学习<br />
<br /><br />
下面是各个文件的作用<br />
&nbsp;&nbsp;&nbsp;&nbsp;index.html ==> 用来测试游戏源码的网页文件;<br />
&nbsp;&nbsp;&nbsp;&nbsp;css/index.css ==> 测试游戏源码的网页样式文件;<br />
&nbsp;&nbsp;&nbsp;&nbsp;js/index.js ==> 测试游戏源码的js文件<br />
&nbsp;&nbsp;&nbsp;&nbsp;js/JicemoonMobileTouch.js ==> 一个简单的touch兼容库(我自己写的, 有在github分享)<br />
&nbsp;&nbsp;&nbsp;&nbsp;js/HardestGame.js ==> 此文件为游戏主要部分, 内含注释<br />
